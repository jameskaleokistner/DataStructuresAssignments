James Kistner
Rene German
CPSC 350-01
11 September 2018

I used 2 different cpp files for this assignment. One was for reading in files, and the other was the syntax checker that contained the functionality for this program. The Genstack class was not connected to this program with any integrated functionality. The stack was kept seperate and was a template class. I have come across no errors or bugs with the program so far.

The main resource I used was a website to help create my template class. I also looked at the book's template class and sort of made my own based off both resources
https://www.cprogramming.com/snippets/source-code/templated-stack-class
# Assignment3
