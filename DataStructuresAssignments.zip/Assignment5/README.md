James Kistner
Rene German
CPSC 350-01
25 November 2018

This assignment was a struggle overall. I was very stuck for a while on the the implementaion of everything. I understood very well in theory how everything was supposed to fit together, but it took some time and I'm not sure if it is the most object-oriented approach. I completed the implementation of everything except the serialization. I spent hours trying to implement serialization, but the sites I found online were wanting me to use the Boost library which was very hard for me to understand. So this program does everything without reading and writing to files. I also couldn't complete the rollback functionality because of the serialization issue.

I tried to debug my program as well as I could, but I'm sure there are a few things that when input is entered incorrectly it will break.

I worked with my roomate (Chase Tullar) on this assignment. I used slack a few times to try and problem solve over the break. Mostly I used the internet. I looked at many more sites than this, but I only used code snipits from the following websites.

https://stackoverflow.com/questions/523872/how-do-you-serialize-an-object-in-c
https://www.geeksforgeeks.org/serialize-deserialize-binary-tree/
https://www.geeksforgeeks.org/switch-statement-cc/
http://www.cplusplus.com/reference/locale/toupper/
https://stackoverflow.com/questions/357307/how-to-call-a-parent-class-function-from-derived-class-function