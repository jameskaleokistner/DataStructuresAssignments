#include "Menu.h"


int main()
{
	Menu menu;
	menu.run();
	return 0;
}