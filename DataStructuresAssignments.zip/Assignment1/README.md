James Kistner
Rene German
CPSC350-01
12 September 2018

In this assignment there are three files
A1Main.cpp
	Main File
A1.cpp
	Contains all the methods
A1.h
	Declares all the methods and variables

Throughout this assignment I mainly used Stack Overflow to solve most of my issues. The main issues I encountered were really just misunderstanding the assignment, but I came to office hours to get it cleared up. The only part of my code that is copy pasted from the web is the clear and seekg methods that reset the file being read in. I understand how it works, but I didn't change it much from what I copied. Below are most of the pages on Stack Overflow that I used.

Also, I'll explain some of how my program works. To start it checks to make sure a valid file in entered and that only one is entered. There are also checks to see if what is being read from the txt file is ACTG, if there are chars that aren't ACTG they are ignored. Most of the method functionality is explained in the comments. I know that there is a lot happening in the main that should be done in a seperate file, but for convenience I did it this way. I lastly have both a txt output file, and a .out output file, the txt file is just for me to see that it works. Overall I give this assignment a 3 out of 10 on difficulty.

https://stackoverflow.com/questions/9912151/math-constant-pi-value-in-c
https://stackoverflow.com/questions/9878965/rand-between-0-and-1
https://stackoverflow.com/questions/30250934/how-to-end-c-code
https://stackoverflow.com/questions/5192068/c-char-argv-vs-char-argv
http://www.cplusplus.com/forum/beginner/73642/


